package com.example.nikote;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class MyAdapter extends ArrayAdapter {
    Activity c;
    ArrayList ar;
    MyAdapter(Activity a,ArrayList b){
        super(a,R.layout.mm,b);
        c=a;
        ar=b;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View rv=c.getLayoutInflater().inflate(R.layout.mm,null,false);
        ImageView iv=rv.findViewById(R.id.cusiv);
        TextView tv=rv.findViewById(R.id.custv);
        tv.setText(ar.get(position).toString());
        iv.setBackgroundResource(R.drawable.town);
        return rv;
    }
}
