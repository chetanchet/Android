package com.example.nikote;

import android.Manifest.permission;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    TextView view_city, view_temp, view_desc, temp_mintv, temp_maxtv, countrytv, winstv;
    ImageView view_weather;
    EditText search;
    static Button search_floating;
    static String cit;
    String mg,cita;
    double Temperature;

    AlertDialog ad;
    AlertDialog.Builder adb;

    FusedLocationProviderClient myLocationClient;
    boolean trackingFlag;
    LocationCallback myCallback;
    double a,b;
    public static final String MYKEY = "my_tracking_location";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("Home");


        view_city = findViewById(R.id.town);
        view_city.setText("--");
        view_temp = findViewById(R.id.temp);
        view_temp.setText("--");
        view_desc = findViewById(R.id.desc);
        view_desc.setText("--");
        temp_mintv = findViewById(R.id.tempmin);
        temp_maxtv = findViewById(R.id.tempmax);
        winstv = findViewById(R.id.wins);

        view_weather = findViewById(R.id.wheather_image);
        view_weather.setBackgroundResource(R.drawable.wheather);
        search = findViewById(R.id.search_edit);
        search_floating = findViewById(R.id.floating_search);


        search.setText(cit);

        search_floating.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = search.getText().toString();
                //Toast.makeText(getApplicationContext(),s,Toast.LENGTH_SHORT).show();
                if(s=="") {
                    Toast.makeText(getApplicationContext(),"Enter city",Toast.LENGTH_SHORT).show();
                }else {
                    //ad.show();
                    hideKeyboard(MainActivity.this);
                    api_key(s);
                }
            }
        });


        adb = new AlertDialog.Builder(this);
        View cv = LayoutInflater.from(this).inflate(R.layout.mydia, null);
        adb.setView(cv);
        ad = adb.create();


        myLocationClient = LocationServices.getFusedLocationProviderClient(this);

        if (savedInstanceState != null)
            trackingFlag = savedInstanceState.getBoolean(MYKEY);

        myCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (trackingFlag) {
                    new GetAddressTask().execute(locationResult.getLastLocation());
                }
            }
        };
        if (!trackingFlag)
            startTrackingLocation();
        else
            stopTrackingLocation();

    }


    public void hideKeyboard(Activity activity) {
        InputMethodManager imm = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        //Find the currently focused view, so we can grab the correct window token from it.
        View view = activity.getCurrentFocus();
        //If no view currently has focus, create a new one, just so we can grab a window token from it
        if (view == null) {
            view = new View(activity);
        }
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    void api_key(final String City) {

        OkHttpClient client = new OkHttpClient();
        //a6f41d947e0542a26580bcd5c3fb90ef
        //e4bd33d237f709b30a4d3f2ff181041f
        Request request = new Request.Builder()
                .url("https://api.openweathermap.org/data/2.5/weather?q=" + City + "&appid=a6f41d947e0542a26580bcd5c3fb90ef&units=metric")
                .get()
                .build();
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        try {
            client.newCall(request).execute();
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    Toast.makeText(getApplicationContext(), "Try Again", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                    String responseData = response.body().string();
                    try {
                        JSONObject jsonmain = new JSONObject(responseData);
                        fncToFetch(jsonmain);

                        //findViewById(R.id.src).setVisibility(View.VISIBLE);
                        ad.dismiss();
                        //Toast.makeText(getApplicationContext(),"Updated seconds ago..",Toast.LENGTH_LONG).show();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void showLocation(View view) {

    }
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putBoolean(MYKEY, trackingFlag);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startTrackingLocation();
            } else {
                Toast.makeText(this, "Location Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void startTrackingLocation() {
        if (ActivityCompat.checkSelfPermission(this, permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{permission.ACCESS_FINE_LOCATION}, 1);
        } else {
            trackingFlag = true;
            Toast.makeText(this, "Location Permission Granted", Toast.LENGTH_SHORT).show();
            // requests periodic location updates
            myLocationClient.requestLocationUpdates(getLocationRequest(), myCallback, null);
        }
    }
    private LocationRequest getLocationRequest() {

        LocationRequest locationRequest = new LocationRequest();
        //locationRequest.setInterval(10000); // Set the desired interval for active location updates, in milliseconds
        //locationRequest.setFastestInterval(5000);// interval of 5000 milliseconds (5 seconds), causes the fused location provider to return location updates that are accurate to within a few feet.
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        return locationRequest;
    }

    private void stopTrackingLocation() {
        if (trackingFlag)
            trackingFlag = false;
    }

    private void setText(final TextView text, final String value) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                text.setText(value);
            }
        });
    }

    void fncToFetch(JSONObject json){
        try{
            JSONArray array = json.getJSONArray("weather");
            JSONObject object = array.getJSONObject(0);
            String description = object.getString("description");
            String icons = object.getString("icon");

            JSONObject temp1 = json.getJSONObject("main");
            Temperature = temp1.getDouble("temp");
            double temp_min = temp1.getDouble("temp_min");
            double temp_max = temp1.getDouble("temp_max");

            String cit=json.getString("name");

            JSONObject syj = json.getJSONObject("sys");
            String country = syj.getString("country");

            JSONObject wj = json.getJSONObject("wind");
            String wins = wj.getString("speed");

            setText(view_city, cit.toUpperCase() + ", " + country);

            String temps = Math.round(Temperature) + " °C";
            setText(view_temp, temps);
            setText(view_desc, description.toUpperCase());
            setText(temp_mintv, temp_min + " °C");
            setText(temp_maxtv, temp_max + " °C");
            setText(winstv, wins + " Kmph");
            setImage(view_weather, icons);
        }catch (Exception e){
            e.printStackTrace();
        }
    }


    private void setImage(final ImageView imageView, final String value) {
        mg = value;
        new Thread(new Runnable() {
            @Override
            public void run() {
                switch (mg) {
                    case "01d":
                    case "01n":
                        imageView.setBackgroundResource(R.drawable.d01d);
                        break;
                    case "02d":
                    case "02n":
                        imageView.setBackgroundResource(R.drawable.d02d);
                        break;
                    case "03d":
                    case "03n":
                        imageView.setBackgroundResource(R.drawable.d03d);
                        break;
                    case "04d":
                    case "04n":
                        imageView.setBackgroundResource(R.drawable.d04d);
                        break;
                    case "09d":
                    case "09n":
                        imageView.setBackgroundResource(R.drawable.d09d);
                        break;
                    case "10d":
                    case "10n":
                        imageView.setBackgroundResource(R.drawable.d10d);
                        break;
                    case "11d":
                    case "11n":
                        imageView.setBackgroundResource(R.drawable.d11d);
                        break;
                    case "13d":
                    case "13n":
                        imageView.setBackgroundResource(R.drawable.d13d);
                        break;
                    default:
                        imageView.setBackgroundResource(R.drawable.wheather);
                        break;

                }
            }
        }).start();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mymenu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mmfav:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        startActivity(new Intent(getApplicationContext(), FavouriteAct.class));
                    }
                }).start();
                break;
            case R.id.mmset:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        if (view_temp.getText().toString().equals("--")) {
                            Toast.makeText(getApplicationContext(), "Enter city", Toast.LENGTH_SHORT).show();
                        } else {
                            double x = (Temperature * 1.8) + 32;
                            Toast.makeText(getApplicationContext(), x + "°F", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).start();
                break;
            case R.id.myloc:
                api_key(cita);
                break;

        }
        return super.onOptionsItemSelected(item);
    }

    public class GetAddressTask extends AsyncTask<Location, Void, String> {

        // @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        protected String doInBackground(Location... locations) {
            //Geocoder geocoder = new Geocoder(ct, Locale.getDefault());

            Location location = locations[0];
            a=location.getLatitude();
            b=location.getLongitude();
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    new Thread(new Runnable() {
                        @Override
                        public void run() {
                            api_key2(a,b);
                        }
                    }).start();
                }
            });
            return "Updated";
        }

        @Override
        protected void onPostExecute(String s) {
            Toast.makeText(getApplicationContext(),"Updated",Toast.LENGTH_SHORT).show();
        }
    }

    public void api_key2(double a,double b) {

        OkHttpClient client = new OkHttpClient();
        //a6f41d947e0542a26580bcd5c3fb90ef
        //e4bd33d237f709b30a4d3f2ff181041f
        Request request = new Request.Builder()
                .url("https://api.openweathermap.org/data/2.5/weather?lat=" + a +"&lon="+b+ "&appid=a6f41d947e0542a26580bcd5c3fb90ef&units=metric")
                .get()
                .build();
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
        try {
            client.newCall(request).execute();
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onResponse(@NotNull okhttp3.Call call, @NotNull Response response) throws IOException {
                    String responseData = response.body().string();
                    try {
                        JSONObject json = new JSONObject(responseData);
                        cita=json.getString("name");
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(@NotNull okhttp3.Call call, @NotNull IOException e) {
                    Toast.makeText(getApplicationContext(), "Try Again", Toast.LENGTH_SHORT).show();
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
