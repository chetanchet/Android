package com.example.nikote;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class FavouriteAct extends AppCompatActivity {

    EditText et, eta, etd;
    Button bt;
    ListView lv;
    ArrayList<String> ar;
    AlertDialog add, ada;
    MyAdapter ad,ad1,ad2;
    static String ck ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favourite);
        getSupportActionBar().setTitle("Favourites");

        MyDataBase md = new MyDataBase(getApplicationContext());
        ar = md.showValues();
        lv = findViewById(R.id.lv);
        //ad = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, ar);
        ad=new MyAdapter(this,ar);
        lv.setAdapter(ad);
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent in = new Intent(getApplicationContext(), MainActivity.class);
                ck = ar.get(i);
                startActivity(in);
            }
        });

        AlertDialog.Builder adab = new AlertDialog.Builder(this);
        adab.setTitle("Add City");
        View cv1 = LayoutInflater.from(this).inflate(R.layout.myc, null);
        adab.setView(cv1);
        eta = cv1.findViewById(R.id.cvet);
        adab.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String sad = eta.getText().toString();
                MyDataBase m2 = new MyDataBase(getApplicationContext());
                m2.insertValues(sad);
                ar = m2.showValues();
                //ad1=new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,ar);
                ad1=new MyAdapter(FavouriteAct.this, ar);
                lv.setAdapter(ad1);
                //recreate();
                //ad.notifyDataSetChanged();
            }
        });
        ada = adab.create();
        AlertDialog.Builder addb = new AlertDialog.Builder(FavouriteAct.this);
        addb.setTitle("Delete All");
        addb.setMessage("Are you sure you want to delete all the cities?");
        addb.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                //int x=ar.indexOf(dad);
                MyDataBase m = new MyDataBase(getApplicationContext());
                m.doDelete();
                ar=m.showValues();
                //ar.remove(dad);
                //ad2=new ArrayAdapter<>(getApplicationContext(),android.R.layout.simple_list_item_1,ar);
                //ad.notifyDataSetChanged();
                ad2=new MyAdapter(FavouriteAct.this,ar);
                lv.setAdapter(ad2);
                //recreate();
                //ad2.notifyDataSetChanged();
                //ad.notifyDataSetChanged();
            }
        });
        add = addb.create();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.meninfo, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.mminfo:
                Toast.makeText(getApplicationContext(), "Click on any city to view weather", Toast.LENGTH_LONG).show();
                break;
            case R.id.mmad:
                ada.show();
                break;
            case R.id.mmde:
                add.show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
