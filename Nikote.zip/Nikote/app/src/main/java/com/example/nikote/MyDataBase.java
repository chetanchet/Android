package com.example.nikote;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;

public class MyDataBase extends SQLiteOpenHelper {
    private static String dbName = "my_database";
    public static int dbVersion = 1;
    Context c;
    MyDataBase(Context c){
        super(c,dbName,null,dbVersion);
        this.c=c;
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        //Toast.makeText(c, "in create", Toast.LENGTH_SHORT).show();
        String s = "create table info(name text unique)";
        sqLiteDatabase.execSQL(s);
    }

    public void insertValues(String s1) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("name", s1);
        db.insert("info", null, cv);
        Toast.makeText(c, "City Added Successfully", Toast.LENGTH_SHORT).show();
    }

    public ArrayList<String> showValues() {
        SQLiteDatabase db = getReadableDatabase();
        String s = "select * from info";
        Cursor cr = db.rawQuery(s, null);
        ArrayList<String> al = new ArrayList<>();
        while (cr.moveToNext()) {
            String s1 = cr.getString(0);
            al.add(s1);
            Log.d("DataBase", s1);
        }
        return al;
    }

    public void doDelete() {
        /*SQLiteDatabase db = getWritableDatabase();
        String where = "name=?";
        String[] ss = {s};
        db.delete("info", where, ss);
        Toast.makeText(c, "City Deleted Successfully", Toast.LENGTH_SHORT).show();*/

        /*SQLiteDatabase ah=getWritableDatabase();
        String cmd="delete from info where name="+st;
        ah.execSQL(cmd);*/


        SQLiteDatabase tb=getWritableDatabase();
        String cm="delete from info";
        tb.execSQL(cm);
        Toast.makeText(c,"Favourites removed",Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
